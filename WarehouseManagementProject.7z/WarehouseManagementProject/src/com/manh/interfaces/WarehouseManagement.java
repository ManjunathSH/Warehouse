package com.manh.interfaces;

import java.util.List;

import com.manh.warehouse.Warehouse;

public interface WarehouseManagement {
	boolean addWarehouse(Warehouse warehouseId);
	boolean deleteWarehouse(int warehouseId);
	List<Warehouse> searchWarehouse(int warehouseId);
}
