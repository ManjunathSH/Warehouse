package com.manh.interfaces;

import com.manh.items.Item;
//import com.manh.warehouse.Warehouse;
import com.manh.zonepack.*;

public interface BulkManagement {

	String addItem(Item item,Batch batch,String itemLocation);
	boolean deleteItem(int warehouseId,int itemCode);
	boolean updateItem(int itemCode,int quantity,int warehouseId);
	boolean moveItem(int itemCode,double quantity,int warehouseId);
	Item searchItemForLocation(int itemCode,int warehouseId);
	boolean editItem(int itemCode,int warehouseId,double price,String unit);
}
