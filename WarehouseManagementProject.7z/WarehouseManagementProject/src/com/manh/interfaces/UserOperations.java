package com.manh.interfaces;

import java.util.ArrayList;

import com.manh.items.Item;
import com.manh.warehouse.Warehouse;
import com.manh.warehousedescription.WarehouseDescription;

public interface UserOperations {
	
	public boolean deleteWarehouse(int warehouseId);
	public boolean searchWarehouse(int warehouseId);
	void addItem(Item item);
	boolean deleteItem(int itemCode);
	Item searchItem(int itemCode);
	ArrayList<Item> getAllItems();
	boolean updateItems(Item item);
	boolean addWarehouse(Warehouse warehouseId);
}
