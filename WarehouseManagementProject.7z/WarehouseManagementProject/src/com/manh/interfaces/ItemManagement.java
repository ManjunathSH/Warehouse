package com.manh.interfaces;

import java.util.ArrayList;

import com.manh.items.Item;

public interface ItemManagement {
	void addItem(Item item);
	boolean deleteItem(int itemCode);
	Item searchItem(int itemCode);
	ArrayList<Item> getAllItems();
	boolean updateItems(Item item);
}
