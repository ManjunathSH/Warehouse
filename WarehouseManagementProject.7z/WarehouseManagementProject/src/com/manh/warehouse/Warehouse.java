package com.manh.warehouse;

import com.manh.warehousedescription.WarehouseDescription;

public class Warehouse {
//	private static int warehouseIdGenerator=101;
	private int warehouseId;
	private String warehouseLocation;
	private String warehouseCity;
	private WarehouseDescription warehouseDescription;
	
	public Warehouse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Warehouse(String warehouseLocation, String warehouseCity) {
		super();
//		warehouseIdGenerator++;
//		this.warehouseId = warehouseIdGenerator;
		this.warehouseLocation = warehouseLocation;
		this.warehouseCity = warehouseCity;
	}
	public int getWarehouseId() {
		return warehouseId;
	}
	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}
	public String getWarehouseLocation() {
		return warehouseLocation;
	}
	public void setWarehouseLocation(String warehouseLocation) {
		this.warehouseLocation = warehouseLocation;
	}
	public String getWarehouseCity() {
		return warehouseCity;
	}
	public void setWarehouseCity(String warehouseCity) {
		this.warehouseCity = warehouseCity;
	}
	
	public WarehouseDescription getWarehouseDescription() {
		return warehouseDescription;
	}
	public void setWarehouseDescription(WarehouseDescription warehouseDescription) {
		this.warehouseDescription = warehouseDescription;
	}
	@Override
	public String toString() {
		return "Warehouse [warehouseId=" + warehouseId + ", warehouseLocation="
				+ warehouseLocation + ", warehouseCity=" + warehouseCity
				+ ", warehouseDescription=" + warehouseDescription + "]";
	}
	
	
}
