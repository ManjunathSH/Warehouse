package com.manh.processmodules;



import java.math.BigDecimal;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.manh.hibernate.HibernateUtil;
import com.manh.items.Category;

public class CategoryProcessModule {
	public static Category getCategory(String category,String subCategory){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		SQLQuery sql = session.createSQLQuery("Select CID from Category_kmn where categoryName=:category and subcategoryName=:subcategory");
		sql.setParameter("category", category);
		sql.setParameter("subcategory", subCategory);
		int cid = ((BigDecimal)sql.list().get(0)).intValueExact();
		
		Category cat = new Category(category,subCategory);
		cat.setCategoryId(cid); 
		transaction.commit();
		session.close();
		return cat;
	}
}
