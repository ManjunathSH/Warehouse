package com.manh.processmodules;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.manh.hibernate.HibernateUtil;
import com.manh.interfaces.WarehouseManagement;
import com.manh.warehouse.Warehouse;

public class WarehouseProcessModule implements WarehouseManagement {

	@Override
	public boolean addWarehouse(Warehouse warehouseId) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(warehouseId);
		transaction.commit();
		session.close();
		return false;
	}

	@Override
	public boolean deleteWarehouse(int warehouseId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		//Warehouse w = new Warehouse();
		//w.setWarehouseId(warehouseId);
	
		Query query=session.createQuery("delete from Warehouse W where W.warehouseId = :Id");
		query.setParameter("Id",warehouseId);
		Query queryDelete=session.createQuery("delete from WarehouseDescription WD where WD.warehouseId=:Id");
		queryDelete.setParameter("Id",warehouseId);
		int result = query.executeUpdate();
		int resultDelete = queryDelete.executeUpdate();
		transaction.commit();
//		session.close();
//		if (result < 0) {
//			return false;
//		}
//		return true;		
		return true;
	}

	@Override
	public List<Warehouse> searchWarehouse(int warehouseId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query=session.createQuery("from Warehouse W where W.warehouseId = :Id");
		query.setParameter("Id",warehouseId);
		List<Warehouse> list2= query.list();
		System.out.println(list2.size());
		transaction.commit();
		session.close();
		
//		Iterator itr2=(list2).iterator();
		return list2;
//		for(Warehouse w : list2){
//			System.out.println(w);
//		}
		
	}

}
