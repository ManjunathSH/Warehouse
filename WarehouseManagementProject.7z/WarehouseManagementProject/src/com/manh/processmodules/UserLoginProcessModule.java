package com.manh.processmodules;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.manh.hibernate.HibernateUtil;
import com.manh.login.LoginAdmin;

public class UserLoginProcessModule {
	public static boolean loginValidateModule(String username, String password) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		Query query = ss
				.createQuery("from LoginUser where username=:uName and password=:Password");
		query.setString("uName", username);
		query.setString("Password", password);
		tx.commit();
		List list = (List) query.list();
		if (list.size() == 0) {
			
			return false;
		} else {
			
			return true;

		}

	}

public static void changePasswordModule(String username,String password) {
	SessionFactory sf = HibernateUtil.getSessionFactory();
	Session session = sf.openSession();
	Transaction tx = session.beginTransaction();
	Query query=session.createQuery("update LoginUser set password=:password where userName=:username");
	query.setString("password", password);
	query.setString("username", username);

	query.executeUpdate();
	tx.commit();
	
}
}