package com.manh.processmodules;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.manh.hibernate.HibernateUtil;
import com.manh.interfaces.ItemManagement;
import com.manh.items.Item;
import com.manh.warehouse.Warehouse;

public class ItemProcessModule implements ItemManagement{
	ArrayList<Item> itemList=new ArrayList<Item>();
	@Override
	public void addItem(Item item) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(item);
		transaction.commit();
		session.close();
	}

	@Override
	public boolean deleteItem(int itemCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Item searchItem(int itemCode) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query=session.createQuery("from Item i where i.itemCode = :Id");
		query.setParameter("Id",itemCode);
		List<Warehouse> list2= query.list();
		System.out.println(list2.size());
		transaction.commit();
		session.close();
		return null;
	}

	@Override
	public ArrayList<Item> getAllItems() {
		
		return itemList;
	}

	@Override
	public boolean updateItems(Item item) {
		// TODO Auto-generated method stub
		return false;
	}

}
