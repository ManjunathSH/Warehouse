package com.manh.processmodules;

import java.util.ArrayList;

import com.manh.interfaces.ItemManagement;
import com.manh.items.Item;

public class ItemProcessModule implements ItemManagement{
	ArrayList<Item> itemList=new ArrayList<Item>();
	@Override
	public void addItem(Item item) {
		// TODO Auto-generated method stub
		itemList.add(item);
	}

	@Override
	public boolean deleteItem(int itemCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Item searchItem(int itemCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Item> getAllItems() {
		
		return itemList;
	}

	@Override
	public boolean updateItems(Item item) {
		// TODO Auto-generated method stub
		return false;
	}

}
