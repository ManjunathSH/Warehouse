package com.manh.processmodules;
import java.util.ArrayList;
import java.util.HashMap;
import com.manh.interfaces.BulkManagement;
import com.manh.items.Item;
import com.manh.zonepack.Batch;

public class BulkProcessModule implements BulkManagement{
	ArrayList<Batch> quantityOnHand=new ArrayList<Batch>();
	private static HashMap<Integer,ArrayList<Batch>> mapInventory = new HashMap<Integer,ArrayList<Batch>>();

	Batch batch=new Batch();
	
	
	public void calculateBeginningInventory()
	{
		
	}
	@Override
	public String addItem(Item item, Batch batch, String itemLocation) {
		
		return null;
	}

	@Override
	public boolean deleteItem(int warehouseId, int itemCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateItem(int itemCode, int quantity, int warehouseId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean moveItem(int itemCode, double quantity, int warehouseId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Item searchItemForLocation(int itemCode, int warehouseId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean editItem(int itemCode, int warehouseId, double price, String unit) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
