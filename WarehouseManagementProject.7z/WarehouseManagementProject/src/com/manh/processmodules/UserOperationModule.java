package com.manh.processmodules;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;

import com.manh.interfaces.UserOperations;
import com.manh.items.Item;
import com.manh.warehouse.Warehouse;
import com.manh.warehousedescription.WarehouseDescription;

public class UserOperationModule implements UserOperations{
	WarehouseProcessModule warehouseprocessmodule = new WarehouseProcessModule();
	@Override
	public boolean addWarehouse(Warehouse warehouseId) {
		
		warehouseprocessmodule.addWarehouse(warehouseId);
		return false;
	}

	@Override
	public boolean deleteWarehouse(int warehouseId) {
		boolean status=warehouseprocessmodule.deleteWarehouse(warehouseId);
		return status;
	}

	@Override
	public List<Warehouse> searchWarehouse(int warehouseId) {
		List<Warehouse> warehouse=warehouseprocessmodule.searchWarehouse(warehouseId);
		return warehouse;
	}

	@Override
	public void addItem(Item item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean deleteItem(int itemCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Item searchItem(int itemCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Item> getAllItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateItems(Item item) {
		// TODO Auto-generated method stub
		return false;
	}

}
