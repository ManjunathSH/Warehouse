package com.manh.warehousedescriptionmodule;

public class WarehouseDescriptionModule {
	private int warehouseId;
	private int zone;
	private int aisle;
	private int bay;
	private int level;
	private int bin;
	private int binThreshold;
	public WarehouseDescriptionModule(int warehouseId, int zone, int aisle, int bay, int level, int bin,int binThreshold) {
		super();
		this.warehouseId = warehouseId;
		this.zone = zone;
		this.aisle = aisle;
		this.bay = bay;
		this.level = level;
		this.bin = bin;
		this.binThreshold=binThreshold;
	}

	public int getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}

	public int getZone() {
		return zone;
	}

	public void setZone(int zone) {
		this.zone = zone;
	}

	public int getAisle() {
		return aisle;
	}

	public void setAisle() {
		this.aisle = 10;
	}

	public int getBay() {
		return bay;
	}

	public void setBay() {
		this.bay = 10;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getBin() {
		return bin;
	}

	public void setBin() {
		this.bin = 2;
	}

	public int getBinThreshold() {
		return binThreshold;
	}

	public void setBinThreshold(int binThreshold) {
		this.binThreshold = binThreshold;
	}

	@Override
	public String toString() {
		return "WarehouseDescriptionModule [warehouseId=" + warehouseId + ", zone=" + zone + ", aisle=" + aisle
				+ ", bay=" + bay + ", level=" + level + ", bin=" + bin + ", binThreshold=" + binThreshold + "]";
	}

	
	
}
