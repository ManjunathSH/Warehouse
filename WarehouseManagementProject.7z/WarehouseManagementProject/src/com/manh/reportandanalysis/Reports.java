package com.manh.reportandanalysis;

public class Reports {
	
		public double turnOverPerMonth(int warehouseID)
		{
			double totalConsumptionCost=0 ;
			double beginningInventory =0;
			double endingInventory=0;
			double turnover=(totalConsumptionCost / (beginningInventory + endingInventory)/2);
					
			return turnover;
		}

		public void stockQuantity(int warehouseID)
		{
			
		}
		
		public void slowMovingItems(int warehouseID)
		{
			
		}
		
		public double obseleteStock(int warehouseID)
		{
		 
			double bookValueOfObsoleteItems=0;
			double totalBookValue=0; 
			double obseleteInventory=((bookValueOfObsoleteItems) *100)/totalBookValue;
			return obseleteInventory;
		}
		
		public double expiredDrugAnalysis(int warehouseID)
		{
			double percentageOfExpiredDrugs=0;
			double totalQuantityOnHandOfExpiredDrugs=0;
			double totalQuantityOfDrugs=0;
			percentageOfExpiredDrugs = ((totalQuantityOnHandOfExpiredDrugs)*100)/totalQuantityOfDrugs;
			return percentageOfExpiredDrugs;
					
		}
	}


