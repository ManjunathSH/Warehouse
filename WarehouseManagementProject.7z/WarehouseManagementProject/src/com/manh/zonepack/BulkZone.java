package com.manh.zonepack;

import com.manh.items.Item;
import com.manh.warehouse.Warehouse;

public class BulkZone {
	private String locationId;
	private Warehouse warehouse;
	private Item item;
	private double quantityOnHand;
	
	private static int bin=0;
	private static int level=0;
	private static int bay=0;
	private static int aisle=0;
	private static char zone=0;
	public BulkZone(Warehouse warehouse, Item item, double quantityOnHand) {
		super();
		this.warehouse = warehouse; 
		this.item = item;
		this.locationId = generateItemLocation();
		this.quantityOnHand = quantityOnHand;
	}
	public String generateItemLocation(){
		StringBuffer location = new StringBuffer();;
		if(bin<2){
			bin++;
		}else{
			bin=1;
			if(level<100)
				level++;
			else{
				level=1;
				if(bay<10)
					bay++;
				else{
					bay=1;
					if(aisle<10){
						aisle++;
					}
					else{
						aisle=1;
						zone++;
						
					}
				}
				
			}
				
		}
		location.append(zone+"-"+aisle+"-"+bay+"-L"+level+"-"+bin);
		return location.toString();
	}

	public Warehouse getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(Warehouse warehouse) {
		this.warehouse = warehouse;
	}

	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public double getQuantityOnHand() {
		return quantityOnHand;
	}
	public void setQuantityOnHand(double quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}
	@Override
	public String toString() {
		return "BulkZone [warehouse=" + warehouse + ", item=" + item + ", locationId=" + locationId
				+ ", quantityOnHand=" + quantityOnHand + "]";
	}

	
	
}
