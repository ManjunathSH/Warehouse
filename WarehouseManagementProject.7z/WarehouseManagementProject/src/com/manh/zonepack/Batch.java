package com.manh.zonepack;

//import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
//import java.util.HashMap;

import com.manh.items.Item;

public class Batch {
//	private static HashMap<Integer,Integer> batchCodeGenerator = new HashMap<Integer,Integer>();
	private int batchCode;
	private Item item;
	private Calendar dateOfArrival;  
	private Calendar dateOfManufacture;
	private Calendar dateOfExpiry;
	private double quantity;
	private int warehouseId;
	
	public Batch() {
		super();
		// TODO Auto-generated constructor stub
	}
	
public int getBatchCode() {
		return batchCode;
	}

	public void setBatchCode(int batchCode) {
		this.batchCode = batchCode;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Calendar getDateOfArrival() {
		return dateOfArrival;
	}

	public void setDateOfArrival(Calendar dateOfArrival) {
		this.dateOfArrival = dateOfArrival;
	}

	public Calendar getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(Calendar dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	public Calendar getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(Calendar dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public int getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}

public Batch(int batchCode, Item item, Calendar dateOfArrival,
			Calendar dateOfManufacture, Calendar dateOfExpiry, double quantity,
			int warehouseId) {
		super();
		this.batchCode = batchCode;
		this.item = item;
		this.dateOfArrival = dateOfArrival;
		this.dateOfManufacture = dateOfManufacture;
		this.dateOfExpiry = dateOfExpiry;
		this.quantity = quantity;
		this.warehouseId = warehouseId;
	}

	//	public Batch(Item item, Date dateOfManufacture, Date dateOfExpiry,
//			double quantity, int warehouseId) {
//		super();
////		if(batchCodeGenerator.get(itemCode)!=null){
////			int code= batchCodeGenerator.get(itemCode);
////			code++;
////			batchCodeGenerator.put(itemCode, code);
////		}else{
////			batchCodeGenerator.put(itemCode, 101);
////		}
////		this.batchCode = batchCodeGenerator.get(itemCode);
//		this.item = item;
//		this.dateOfArrival = Calendar.getInstance();
//		this.dateOfManufacture = Calendar.getInstance();
//		this.dateOfExpiry = Calendar.getInstance();
//		this.quantity = quantity;
//		this.warehouseId = warehouseId;
//	}
//	public int getBatchCode() {
//		return batchCode;
//	}
//	public void setBatchCode(int batchCode) {
//		this.batchCode = batchCode;
//	}
//
//	public Item getItem() {
//		return item;
//	}
//	public void setItem(Item item) {
//		this.item = item;
//	}
//	//	public void setDateOfArrival(Date dateOfArrival) {
////		this.dateOfArrival = dateOfArrival;
////	}
//	
//	public Calendar getDateOfManufacture() {
//		return dateOfManufacture;
//	}
//	public Calendar getDateOfArrival() {
//		return dateOfArrival;
//	}
//	//	public void setDateOfManufacture(Date dateOfManufacture) {
////		this.dateOfManufacture = dateOfManufacture;
////	}
//	public Calendar getDateOfExpiry() {
//		return dateOfExpiry;
//	}
////	public void setDateOfExpiry(Date dateOfExpiry) {
////		this.dateOfExpiry = dateOfExpiry;
////	}
//	public double getQuantity() {
//		return quantity;
//	}
//	public void setQuantity(double quantity) {
//		this.quantity = quantity;
//	}
//	public int getWarehouseId() {
//		return warehouseId;
//	}
//	public void setWarehouseId(int warehouseId) {
//		this.warehouseId = warehouseId;
//	}
	@Override
	public String toString() {
		return "Batch [batchCode=" + batchCode + ", item=" + item + ", dateOfArrival=" + dateOfArrival
				+ ", dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", quantity="
				+ quantity + ", warehouseId=" + warehouseId + "]";
	}

	
}
