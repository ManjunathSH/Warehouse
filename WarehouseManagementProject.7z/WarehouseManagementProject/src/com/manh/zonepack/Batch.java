package com.manh.zonepack;

import java.text.ParseException;
import java.text.SimpleDateFormat;
//import java.util.ArrayList;
import java.util.Calendar;
//import java.util.Date;
//import java.util.HashMap;

import com.manh.items.Item;
import com.manh.warehouse.Warehouse;

public class Batch {
//	private static HashMap<Integer,Integer> batchCodeGenerator = new HashMap<Integer,Integer>();
	private int batchCode;
	private Item item;
	private Calendar dateOfArrival = Calendar.getInstance();  
	private Calendar dateOfManufacture= Calendar.getInstance();
	private Calendar dateOfExpiry = Calendar.getInstance();
	private double quantity;
	private Warehouse warehouseId;
	private SimpleDateFormat dateFormater = new SimpleDateFormat("dd/MM/yyyy");
	public Batch() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getBatchCode() {
		return batchCode;
	}

	public void setBatchCode(int batchCode) {
		this.batchCode = batchCode;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Calendar getDateOfArrival() {
		return dateOfArrival;
	}

	public void setDateOfArrival(String dateOfArrival) throws ParseException {
		this.dateOfArrival.setTime(dateFormater.parse(dateOfArrival));
	}

	public Calendar getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(String dateOfManufacture) throws ParseException {
		this.dateOfManufacture.setTime(dateFormater.parse(dateOfManufacture));
	}

	public Calendar getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(String dateOfExpiry) throws ParseException {
		this.dateOfExpiry.setTime(dateFormater.parse(dateOfExpiry));
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	

	public Warehouse getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(Warehouse warehouseId) {
		this.warehouseId = warehouseId;
	}

    public Batch(Item item, String dateOfArrival,
			String dateOfManufacture, String dateOfExpiry, double quantity,
			Warehouse warehouseId) throws ParseException {
		super();
//		this.batchCode = batchCode;
		
		this.item = item;
			this.dateOfArrival.setTime(dateFormater.parse(dateOfArrival));
			this.dateOfManufacture.setTime(dateFormater.parse(dateOfManufacture));
			this.dateOfExpiry.setTime(dateFormater.parse(dateOfExpiry));
		
			this.quantity = quantity;
			this.warehouseId = warehouseId;
		
	}


	
}
