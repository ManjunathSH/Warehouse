package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.manh.processmodules.AdminOperationModule;
import com.manh.processmodules.UserOperationModule;

/**
 * Servlet implementation class DeleteWarehouseServlet
 */
public class DeleteWarehouseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteWarehouseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int warehouseId=Integer.parseInt(request.getParameter("warehouseId"));
		HttpSession session = request.getSession(true);

		String users=session.getAttribute("role").toString();
		if(users.equals("admin"))
		{
			UserOperationModule adminModule=new AdminOperationModule();
			adminModule.deleteWarehouse(warehouseId);
			response.sendRedirect("AdminOptions.jsp");
		}
		else
		{
			UserOperationModule userModule=new UserOperationModule();
			userModule.deleteWarehouse(warehouseId);
			response.sendRedirect("UserOptions.jsp");
		}
	}

}
