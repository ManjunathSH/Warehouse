package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.manh.processmodules.AdminLoginProcessModule;
import com.manh.processmodules.AdminOperationModule;
import com.manh.processmodules.UserOperationModule;
import com.manh.warehouse.Warehouse;
import com.manh.warehousedescription.WarehouseDescription;

/**
 * Servlet implementation class AddWarehouseServlet
 */
public class AddWarehouseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddWarehouseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String warehouseLocation=request.getParameter("warehouseLocation");
		String warehouseCity=request.getParameter("warehouseCity");
		int aisle=Integer.parseInt(request.getParameter("aisle"));
		int bay=Integer.parseInt(request.getParameter("bay"));
		int level=Integer.parseInt(request.getParameter("level"));
		int bin=Integer.parseInt(request.getParameter("bin"));
		int zone=Integer.parseInt(request.getParameter("zone"));
		Warehouse warehouse=new Warehouse( warehouseLocation,warehouseCity);
		WarehouseDescription warehouseDescription=new WarehouseDescription(warehouse,zone,aisle,bay,level,bin);
		HttpSession session = request.getSession(false);
		String users=session.getAttribute("role").toString();
		if(users.equals("admin"))
		{
			UserOperationModule adminModule=new AdminOperationModule();
			warehouse.setWarehouseDescription(warehouseDescription);
			adminModule.addWarehouse(warehouse);
			response.sendRedirect("AdminOptions.jsp");
		}
		else
		{
			UserOperationModule userModule=new UserOperationModule();
			warehouse.setWarehouseDescription(warehouseDescription);
			userModule.addWarehouse(warehouse);
			response.sendRedirect("UserOptions.jsp");
		}
		
	}

}
