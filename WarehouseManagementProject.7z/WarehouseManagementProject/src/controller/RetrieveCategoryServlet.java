package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.google.gson.Gson;
import com.manh.hibernate.HibernateUtil;
import com.manh.items.Category;
import com.manh.warehouse.Warehouse;

/**
 * Servlet implementation class testServlet
 */
public class RetrieveCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RetrieveCategoryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
        String categoryName = request.getParameter("categoryName");
       // List<String> lists = new ArrayList<String>();
        String jsons = null;
        
        if (categoryName.equals("Pharma Drug")) {
        
    		Transaction transaction = session.beginTransaction();
    		Query query=session.createQuery("Select subcategoryName from Category where categoryName=:name");
    		query.setParameter("name","Pharma Drug");
    		List<String> lists= query.list();
    		
          jsons = new Gson().toJson(lists);
            response.setContentType("application/json");
            response.getWriter().write(jsons);
               
        } else if (categoryName.equals("Health And Personal Care")) {
        	
    		Transaction transaction = session.beginTransaction();
    		Query query=session.createQuery("Select subcategoryName from Category where categoryName=:name");
    		query.setParameter("name","Health and Personal Care");
    		List<String> lists= query.list();
    		
          jsons = new Gson().toJson(lists);
            response.setContentType("application/json");
            response.getWriter().write(jsons);
        }  else if (categoryName.equals("Baby care")) {
        	
    		Transaction transaction = session.beginTransaction();
    		Query query=session.createQuery("Select subcategoryName from Category where categoryName=:name");
    		query.setParameter("name","Baby Care");
    		List<String> lists= query.list();
    		
          jsons = new Gson().toJson(lists);
            response.setContentType("application/json");
            response.getWriter().write(jsons);
        }
        else if (categoryName.equals("Medical Supplies and Equipments")) {
        	
    		Transaction transaction = session.beginTransaction();
    		Query query=session.createQuery("Select subcategoryName from Category where categoryName=:name");
    		query.setParameter("name","Medical Supplies and Equipments");
    		List<String> lists= query.list();
    	
          jsons = new Gson().toJson(lists);
            response.setContentType("application/json");
            response.getWriter().write(jsons);
        }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
