package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.manh.items.Category;
import com.manh.items.Item;
import com.manh.processmodules.AdminOperationModule;
import com.manh.processmodules.CategoryProcessModule;
import com.manh.processmodules.UserOperationModule;

/**
 * Servlet implementation class AddItemServlet
 */
public class AddItemServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddItemServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String itemName = request.getParameter("itemName");
		double itemPrice = Double.parseDouble(request.getParameter("price"));
		double quantity = Double.parseDouble(request.getParameter("quantity"));
		String unit = request.getParameter("unitQuantity").concat(request.getParameter("unit"));
		String category = request.getParameter("category");
		String subCategory = request.getParameter("subcategory");
		Category cat = CategoryProcessModule.getCategory(category, subCategory);
//		Category cat = new Category(category,subCategory);
//		
		Item item = new Item(itemName,itemPrice,unit,cat);
		
		HttpSession session = request.getSession(false);
		String users=session.getAttribute("role").toString();
		if(users.equals("admin"))
		{
			UserOperationModule adminModule=new AdminOperationModule();
			
			adminModule.addItem(item);
			response.sendRedirect("AdminOptions.jsp");
		}
		else
		{
			UserOperationModule userModule=new UserOperationModule();
			
			userModule.addItem(item);
			response.sendRedirect("UserOptions.jsp");
		}
	}

}
